// src/components/TruckCard.tsx
import React from 'react';
import { Truck } from '../pages/Trucks';
import { useNavigate } from 'react-router-dom';

interface TruckCardProps {
  truck: Truck;
}

export const TruckCard: React.FC<TruckCardProps> = ({ truck }) => {
  const navigate = useNavigate();

  const handleDetails = () => {
    navigate(`/trucks/${truck.id}/deliveries`);
  };

  return (
    <div
      onClick={handleDetails}
      className="max-w-sm p-6 bg-white rounded-2xl shadow-md hover:shadow-xl transform hover:-translate-y-1 transition cursor-pointer"
    >
      <h2 className="text-2xl font-semibold mb-2">{truck.model}</h2>
      <p className="text-gray-600 mb-4">Make: {truck.make}</p>
      <p className="text-gray-600 mb-4">Year: {truck.year}</p>
      <button
        onClick={(e) => { e.stopPropagation(); handleDetails(); }}
        className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
      >
        Start Delivery
      </button>
    </div>
  );
};
```

```tsx
// src/pages/Trucks.tsx
import React, { useEffect, useState } from 'react';
import api from '../api/api';
import { TruckCard } from '../components/TruckCard';

export interface Truck {
  id: number;
  model: string;
  make: string;
  year: number;
}

export const Trucks: React.FC = () => {
  const [trucks, setTrucks] = useState<Truck[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/trucks')
      .then(res => setTrucks(res.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p className="text-center mt-8">Loading…</p>;

  return (
    <div className="p-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {trucks.length === 0 ? (
        <p className="col-span-full text-center text-gray-500">No trucks yet.</p>
      ) : (
        trucks.map(truck => (
          <TruckCard key={truck.id} truck={truck} />
        ))
      )}
    </div>
  );
};
