// // src/components/TruckCard.tsx
// import React from 'react';
// import { Truck } from '../pages/Trucks';
// import { useNavigate } from 'react-router-dom';

// interface TruckCardProps {
//   truck: Truck;
// }

// export const TruckCard: React.FC<TruckCardProps> = ({ truck }) => {
//   const navigate = useNavigate();

//   const handleDetails = () => {
//     navigate(`/trucks/${truck.id}/deliveries`);
//   };

//   return (
//     <div
//       onClick={handleDetails}
//       className="max-w-sm p-6 bg-white rounded-2xl shadow-md hover:shadow-xl transform hover:-translate-y-1 transition cursor-pointer"
//     >
//       <h2 className="text-2xl font-semibold mb-2">{truck.model}</h2>
//       <p className="text-gray-600 mb-4">Make: {truck.make}</p>
//       <p className="text-gray-600 mb-4">Year: {truck.year}</p>
//       <button
//         onClick={(e) => { e.stopPropagation(); handleDetails(); }}
//         className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
//       >
//         Start Delivery
//       </button>
//     </div>
//   );
// };