import { useState } from 'react';
import './App.css' ;
// Sample truck data - you can replace this with your API data later
const initialTrucks = [
  { id: 1, make: "Ford", model: "F-150", year: 2023 },
  { id: 2, make: "Chevrolet", model: "Silverado", year: 2022 },
  { id: 3, make: "RAM", model: "1500", year: 2023 },
  { id: 4, make: "Toyota", model: "Tundra", year: 2021 },
  { id: 5, make: "GMC", model: "Sierra", year: 2022 },
  { id: 6, make: "Nissan", model: "Titan", year: 2020 }
];

export default function TruckCardsDisplay() {
  const [trucks] = useState(initialTrucks);

  interface Truck {
    id: number;
    make: string;
    model: string;
    year: number;
  }

  const handleDetails = (truckId: number): void => {
    console.log(`Navigating to truck ${truckId} deliveries`);
    // Navigation would go here using your router
  };

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold mb-8 text-center">Truck Fleet</h1>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {trucks.map(truck => (
          <div 
            key={truck.id}
            onClick={() => handleDetails(truck.id)}
            className="bg-white rounded-2xl shadow-md hover:shadow-xl transform hover:-translate-y-1 transition cursor-pointer overflow-hidden"
          >
            {/* Image placeholder - you can replace this with actual truck images later */}
            <div className="bg-gray-200 h-48 relative">
              <img 
                src="/api/placeholder/400/320" 
                alt={`${truck.make} ${truck.model}`}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-3 right-3 bg-blue-600 text-white px-2 py-1 rounded-lg text-sm">
                {truck.year}
              </div>
            </div>
            
            <div className="p-6">
              <h2 className="text-2xl font-semibold mb-2">{truck.make} {truck.model}</h2>
              <div className="flex justify-between items-center mt-4">
                <span className="text-gray-600">ID: #{truck.id}</span>
                <button
                  onClick={(e) => { 
                    e.stopPropagation(); 
                    handleDetails(truck.id); 
                  }}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
                >
                  Start Delivery
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}