
```tsx
// src/pages/Trucks.tsx
import React, { useEffect, useState } from 'react';
import api from '../api/api';
import { TruckCard } from '../components/TruckCard';

export interface Truck {
  id: number;
  model: string;
  make: string;
  year: number;
}

export const Trucks: React.FC = () => {
  const [trucks, setTrucks] = useState<Truck[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/trucks')
      .then(res => setTrucks(res.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p className="text-center mt-8">Loading…</p>;

  return (
    <div className="p-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {trucks.length === 0 ? (
        <p className="col-span-full text-center text-gray-500">No trucks yet.</p>
      ) : (
        trucks.map(truck => (
          <TruckCard key={truck.id} truck={truck} />
        ))
      )}
    </div>
  );
};
