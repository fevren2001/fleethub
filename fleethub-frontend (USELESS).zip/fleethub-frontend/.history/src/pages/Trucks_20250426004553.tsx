import React, { useEffect, useState } from 'react';
import api from '../api/api';

interface Truck {
  id: number;
  model: string;
  make: string;
  year: number;
}

export const Trucks: React.FC = () => {
  const [trucks, setTrucks] = useState<Truck[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/trucks')
      .then(res => setTrucks(res.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p>Loading…</p>;
  return (
    <div className="p-4">
      <h1 className="text-xl mb-4">Your Trucks</h1>
      {trucks.length === 0 && <p>No trucks yet.</p>}
      <ul>
        {trucks.map(t => (
          <li key={t.id}>
            {t.model} — {t.make} ({t.year})
          </li>
        ))}
      </ul>
    </div>
  );
};
