import { defineConfig } from 'vite'
import tailwindcss from '@tailwindcss/vite'
export default defineConfig({
  plugins: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  ],
})